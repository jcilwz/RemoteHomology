sequence_length = 400
window_size = 3
nb_of_epochs = 150
nb_of_cells = 50
